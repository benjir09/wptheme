<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package aistartup
 */

get_header();
?>

	<main id="primary" class="site-main">

		<section class="page-banner-section">
			<div class="container">
				<h2 class="aistartup-title text-white"><?php the_title();?></h2>
			</div>
		</section>

		<!-- page main content -->
		<section class="page-content-section">
			<div class="container">
				<div class="page-content-wrap">
					<?php 
					if( have_posts(  ) ):
						while( have_posts(  ) ) :
							the_post();
							?>
							<div class="page-thumbnail">
								<?php the_post_thumbnail(  ); ?>
							</div>
							<div class="page-content">
								<?php the_content();?>
							</div>
							<?php
						endwhile;
					endif;
					?>
				</div>
			</div>
		</section>
		<!-- page main content -->

	</main><!-- #main -->

<?php
get_footer();
