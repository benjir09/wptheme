        <!-- footer -->
        <footer class="site-footer">
            <div class="main-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Address', 'aistartup');?></h3>
                                        <address>
                                            <?php echo get_field('footer_address', 'option')?>
                                        </address>
                                    </div>
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Phone', 'aistartup');?></h3>
                                        <?php
                                        $phone_number = get_field('phone', 'option');
                                        $pure_number = preg_replace('/[^0-9]/', '', $phone_number);
                                        ?>
                                        <a href="tel:<?php echo $pure_number;?>"><?php echo esc_html( $phone_number )?></a>
                                    </div>
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Email', 'aistartup');?></h3>
                                        <a class="footer-mail-link" href="mailto:<?php echo get_field('email', 'option');?>"><?php echo esc_html( get_field('email', 'option') )?></a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Weekdays', 'aistartup');?></h3>
                                        <p><?php echo get_field('week_days_text', 'option')?></p>
                                    </div>
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Weekends', 'aistartup');?></h3>
                                        <p> <?php echo get_field('weekends_text', 'option')?></p>
                                    </div>
                                    <div class="address-content d-flex">
                                        <h3><?php _e('Social Media', 'aistartup');?></h3>
                                        <div class="footer-socail-box d-flex">
                                        <?php
                                            $social_links = get_field('social_links', 'option');
                                            if( $social_links ){
                                                foreach( $social_links as $link ){
                                                    echo '<a href="'.esc_url($link['social_url']).'"> <i class="'.esc_attr( $link['icon_class'] ).'"></i> </a>';
                                                }
                                            }
                                        ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="footer-logo">
                                <?php echo wp_get_attachment_image( get_field('footer_logo', 'option'), 'medium', false, array('class' => 'img-fluid') ); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-footer">
                <div class="container">
                    <div class="footer-copyright-content d-md-flex justify-content-md-between">
                        <p><?php echo get_field('footer_powered_by', 'option')?></p>
                        <p><?php echo get_field('footer_copyright', 'option')?></p>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer -->
    </div>
	<?php wp_footer();?>
</body>
</html>