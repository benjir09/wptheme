<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package aistartup
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div class="site-wrap">
	<header class="site-header">
		<div class="header-top-wrap position-relative">
			<div class="header-top-design"></div>
			<div class="container">
				<div class="header-top d-flex justify-content-between">
					<div class="ht-left">
						<a href="#" class="aistartup-ht-link"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo esc_html( get_field('address', 'option') )?></a>
					</div>
					<div class="ht-right d-flex">
						<div class="aistartup-mail-box">
							<?php
							$phone_number = get_field('phone', 'option');
							$pure_number = preg_replace('/[^0-9]/', '', $phone_number);
							?>
							<a href="tel:<?php echo $pure_number; ?>" class="aistartup-ht-link"><i class="fa fa-phone" aria-hidden="true"></i><?php echo esc_html( $phone_number ); ?></a>
							<a href="mailto:<?php echo esc_html( get_field('email', 'option') )?>" class="aistartup-ht-link"><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo __('Email Us', 'aistartup')?></a>
						</div>
						<div class="aistartup-socail-box">
							<?php
								$social_links = get_field('social_links', 'option');
								if( $social_links ){
									foreach( $social_links as $link ){
										echo '<a href="'.esc_url($link['social_url']).'"> <i class="'.esc_attr( $link['icon_class'] ).'"></i> </a>';
									}
								}
							?>
							
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="main-header">
			<div class="container">
				<div class="header-wrap d-flex justify-content-between align-items-center">
					<div class="site-logo">
						<?php
							if( has_custom_logo(  ) ){
								the_custom_logo(  );
							}else{
								echo '<h2>'.bloginfo( 'title' ).'</h2>';
							}
						?>
					</div>
					<nav class="site-nav">
						<?php
						wp_nav_menu( array(
							'theme_location' => 'menu-1',
							'container' => '',
							'menu_class' => 'main-menu'
						) );
						?>
					</nav>
					<div class="menu-toggle d-lg-none">
						<i class="fas fa-bars"></i>
					</div>
				</div>
			</div>
		</div>
	</header>