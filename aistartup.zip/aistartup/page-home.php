<?php
/**
 * Template Name: Home
 */
get_header(); 
?>
        <!-- hero section -->
        <section class="site-hero">
            <div class="site-hero-slider">
            <?php
                $hero_slider = get_field('hero_slider');
                if( $hero_slider ) :
                    foreach( $hero_slider as $slide ) :
            ?>
                <div class="site-hero-slide">
                    <div class="site-hero-slide-content" style="background: url(<?php echo esc_url( $slide['hero_bg'] )?>);">
                        <div class="container">
                            <div class="hero-content text-center">
                                <h1 class="site-hero-title"><?php echo esc_html( $slide['hero_title'] )?>
                                <span><?php echo esc_html( $slide['hero_subtitle'] )?></span>  </h1>
                                <a href="<?php echo esc_url( $slide['hero_btn']['url'] )?>" class="button btn-primary"><?php echo esc_html( $slide['hero_btn']['title'] )?></a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            <?php
                    endforeach;
                endif;
            ?>
            </div>
            
        </section>
        <!-- hero section -->
        <?php
        $safety_sec = get_field( 'safety_section' );

        if( $safety_sec ) :
        ?>
        <section class="safty-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="safty-img">
                            <?php
                                $safety_img = $safety_sec['safety_image'];
                                if( $safety_img ){
                                    echo wp_get_attachment_image( $safety_img, 'large' );
                                }
                            ?>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="safty-shop-content">
                            <h2 class="aistartup-title"><?php echo esc_html( $safety_sec['safety_title'] )?></h2>
                            <div class="aistartup-content-box">
                                <?php echo wpautop( $safety_sec['safety_desc'] );?>
                            </div>
                            <div class="safty-btn-wrap d-sm-flex">
                                <a href="<?php echo esc_url( $safety_sec['safety_learn_more']['url'] );?>" class="button btn-primary"><?php echo esc_html( $safety_sec['safety_learn_more']['title'] );?></a>
                                <a href="<?php echo esc_url( $safety_sec['safety_contact_link']['url'] );?>" class="button btn-outline"><?php echo esc_html( $safety_sec['safety_contact_link']['title'] );?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <!-- quick link section -->
        <section class="quick-link-section">
            <div class="quick-link-wrap d-lg-flex">
            <?php
            $ql_content = get_field('quick_links');
            if( $ql_content ) :
                foreach( $ql_content as $ql ) :
            ?>
                <div class="quick-link-content">
                    <?php
                        echo wp_get_attachment_image( $ql['quick_link_img'], 'large', false, array( 'class' => 'qc-img' ) );
                    ?>
                    <div class="quick-link-text-content text-center">
                        <?php
                            echo wp_get_attachment_image( $ql['quick_link_icon'], 'thumbnail', false, array( 'class' => 'img-fluid' ) );
                        ?>
                        <h2 class="aistartup-title"><?php echo esc_html( $ql['quick_link_title'] )?></h2>
                        <p><?php echo esc_html( $ql['quick_link_desc'] )?></p>
                    </div>
                </div>
            <?php
                endforeach;
            endif;
            ?>
            </div>
        </section>
        <!-- quick link section -->

        <!-- certification section -->
        <section class="certification">
            <div class="container">
                <div class="certification-content-wrap d-lg-flex justify-content-around">
                <?php
                    $cartf = get_field( 'certification' );
                    if( $cartf ) :
                        foreach( $cartf as $content ) :
                ?>
                    <div class="certification-content text-center">
                        <?php echo wp_get_attachment_image( $content['certification_img'], 'large' );?>
                        <h2 class="aistartup-title"><?php echo esc_html( $content['certification_title'] )?></h2>
                        <p><?php echo esc_html( $content['certification_descrip'] )?></p>
                        <a href="<?php echo esc_url( $content['certification_link']['url'] )?>" class="button btn-primary"><?php echo esc_html( $content['certification_link']['title'] )?></a>
                    </div>
                <?php
                        endforeach;
                    endif;
                ?>
                </div>
            </div>
        </section>
        <!-- certification section -->

        <?php
        $product = get_field('product_categories');
        if( $product ) :
        ?>
        <!-- product category-section -->
        <section class="product-category-section position-relative">
            
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="product-category-sec-head">
                            <h2 class="pro-cate-title">
                                <?php echo esc_html( $product['section_title'] ); ?>
                                <span><?php echo esc_html( $product['section_subtitle'] ); ?></span>
                            </h2>
                        </div>
                    </div>
                    <div class="col-lg-9">
                    <?php
                        $categories = $product['categories'];
                        if( $categories ) :
                    ?>
                        <div class="product-cate-slider">
                        <?php
                            foreach( $categories as $cate ) :
                        ?>
                            <div class="product-cate-slide">
                                <div class="prodct-cate-content text-center">
                                    <?php echo wp_get_attachment_image( $cate['category_image'], 'thumbnail' );?>
                                    <h2><?php echo esc_html( $cate['category_title'] )?></h2>
                                    <p><?php echo esc_html( $cate['category_desc'] )?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>
        <!-- product category-section -->
<?php get_footer(); ?>