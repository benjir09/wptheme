(function($){


$('.product-cate-slider').slick({
    slidesToShow: 4,
    arrows: false,
    autoplay: true,
    responsive: [
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
            }
        },
        {
            breakpoint: 767,
            settings: {
                slidesToShow: 1,
            }
        }
    ]
});

$('.site-hero-slider').slick({
    arrows: false,
    autoplay: true
});

$(document).ready(function(){
    const mainHeader = $('.main-header');
    $(document).on('scroll', function(e){
        if( window.scrollY > 100 ){
            mainHeader.addClass('active-sticky')
            $('.site-nav').removeClass('active-site-nav')
        }else{
            mainHeader.removeClass('active-sticky')
        }
    });

    $('.menu-toggle').on('click', function(){
        $('.site-nav').toggleClass('active-site-nav')
    });
});

})(jQuery)